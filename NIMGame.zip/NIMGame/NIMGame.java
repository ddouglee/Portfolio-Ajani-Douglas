/*
 Name: Ajani Douglas
 Project: Play the NIM Game for as many rounds as you'd like with another human player.
 Date: April 14, 2025
 */
 //BEGIN
import java.util.Scanner;
public class NIMGame
{
	Scanner in = new Scanner(System.in);
	
	//Method that serves to give each pile a random amount of sticks between 4 and 8.
	public static int getSticks() 
	{
		Scanner in = new Scanner(System.in);
		int pile = (int)(Math.random()*5 + 4);
		return pile;
	}
	
	//Method that removes the user's desired number of sticks, but it doesn't allow the player to remove more than 3.
	public static int removeStick(int pile)
	{
		Scanner in = new Scanner(System.in);
		System.out.println("How many sticks would you like to remove from this pile?");
		int removed = in.nextInt();
		while(removed > pile || removed > 3 || removed <= 0)
		{
			System.out.println("You've selected an invalid number of sticks");
			System.out.println("Try again, how many sticks would you like to remove from this pile? ");
			removed=in.nextInt();
		}
		pile = pile - removed;
		return pile;
	}
	
	//Method that dsiplays all the sticks
	public static void displayStick(int pile1, int pile2, int pile3, int pile4)
	{
		System.out.println("Pile 1 has "+pile1+" sticks: ");
		for(int i = 0; i<pile1; i++)
		{
			System.out.print("| ");
		}
		System.out.println();
		System.out.println("Pile 2 has "+pile2+" sticks");
		for(int j = 0; j<pile2; j++)
		{
			System.out.print("| ");
		}
		System.out.println();
		System.out.println("Pile 3 has "+pile3+" sticks");
		for(int k = 0; k<pile3; k++)
		{
			System.out.print("| ");
		}
		System.out.println();
		System.out.println("Pile 4 has "+pile4+" sticks");
		for(int m = 0; m<pile4; m++)
		{
			System.out.print("| ");
		}
		System.out.println();
	}
	
	//Main method that plays the game
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		//Allows the players to name themselves
		System.out.println("What is player 1's name");
		String player1 = in.next();
		System.out.println("What is player 2's name");
		String player2 = in.next();
		
		//Initialising first string that allows the game to repeat as many times as you want.
		String YesNo = "Yes";
		int player1win = 0;
		int player2win = 0;
		while(YesNo.equalsIgnoreCase("Yes"))
		{
			//Initialising the piles, options, the number of times sticks have been removed and the number of times each player wins.
			int pile1 = getSticks();
			int pile2 = getSticks();
			int pile3 = getSticks();
			int pile4 = getSticks();
			int option = 0;
			int times = 1;
			displayStick(pile1,pile2,pile3,pile4);
			
			while(pile1!=0 || pile2!=0 || pile3!=0 || pile4!=0)
			{
				//If else alternates the players.
				if((times%2)!=0)
				{
					System.out.println(player1+"'s turn");
					//Choosing piles for player 1
					System.out.println("Which pile are you choosing? ");
					option = in.nextInt();
					
					if(option == 1)
					{
						
						if(pile1==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile1=removeStick(pile1);
					}
					
					else if(option == 2)
					{
						
						if(pile2==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile2=removeStick(pile2);
					}
					
					else if(option == 3)
					{
						if(pile3==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						pile3=removeStick(pile3);
					}
					
					else if(option == 4)
					{
						
						if(pile4==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile4=removeStick(pile4);
					}
					//If the pile chosen doesnt exist, it brings you back to the beginning
					else
					{	
						System.out.println("This is not a valid option.");
						continue;
					}
					
					times++;	
					displayStick(pile1,pile2,pile3,pile4);
				}
				
				else
				{
					
					System.out.println(player2+"'s turn");
					//Allows player 2 to choose a pile.
					System.out.println("Which pile are you choosing? ");
					option = in.nextInt();
					
					if(option == 1)
					{
						
						if(pile1==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile1=removeStick(pile1);
					}
					
					else if(option == 2)
					{
						
						if(pile2==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile2=removeStick(pile2);
					}
					
					else if(option == 3)
					{
						
						if(pile3==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile3=removeStick(pile3);
					}
					
					else if(option == 4)
					{
						
						if(pile4==0)
						{
							System.out.println("This pile is empty, try again");
							continue;
						}
						
						pile4=removeStick(pile4);
					}
					
					else
					{	
						System.out.println("This is not a valid option.");
						continue;
					}
					
					times++;	
					displayStick(pile1,pile2,pile3,pile4);
				}
				
			}
			//Win statements, also accumulates the win count for each player
			if((times%2)!=0)
			{
				System.out.println(player1+" wins.");
				player1win++;
			}
			
			else
			{
				System.out.println(player2+" wins.");
				player2win++;
			}
			System.out.println("The score is: "+player1win+"-"+player2win);
			//Choose whether to play another round or not
			System.out.println("New Game?(Yes or No ONLY)");
			YesNo = in.next();
		}
	}
}
//END
