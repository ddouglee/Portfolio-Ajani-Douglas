import java.util.Scanner;
public class LottoPicker
{
	public static void main (String[] args) 
	{
		int ticknum;
		int a;
		int numoftick;
		int low;
		int high;
		Scanner in = new Scanner(System.in);
		do
		{
			System.out.println("How many tickets do you want?(1-100000)");
			numoftick = in.nextInt();
			if(numoftick>100000||numoftick<1)
			{
				System.out.println("Invalid data,try again.");
			}
		}while(numoftick>100000||numoftick<1);
		do
		{
			System.out.println("How many numbers are on a ticket?(1-100000)");
			ticknum = in.nextInt();
			if(ticknum>100000||ticknum<1)
			{
				System.out.println("Invalid data,try again.");
			}
		}while(ticknum>100000||ticknum<1);
		do
		{
			System.out.println("What is the lowest possible number?(1-100000)");
			low = in.nextInt();
			if(low>100000||low<1)
			{
				System.out.println("Invalid data,try again.");
			}
		}while(low>100000||low<1);
		do
		{
			System.out.println("What is the highest possible number?(1-100000)");
			high = in.nextInt();
			if(high>100000||high<1)
			{
				System.out.println("Invalid data,try again.");
			}
		}while(high>100000||high<1);
		System.out.println("Your Tickets:");
		int[] lotto = new int[ticknum];
		for(int i = 0; i<numoftick;i++)
		{
			for(int j = 0;j<ticknum;j++)
			{
				do
				{
					a =	(int)(Math.random()*(high-low)+1);
				}while(MyArray.indexOf(lotto,a)>-1);
				lotto[j] = a;
			}
			MyArray.sort(lotto);
			print(lotto);
		}
	}
	public static void print(int[] array)
	{
		for(int b: array)
		{
			System.out.print(b+" ");
		}
		System.out.println();
	}
}

