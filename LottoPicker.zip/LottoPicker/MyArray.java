
public class MyArray
{
	
	public static int max(int[] array)
	{
		int high = 0;
		for(int x: array)
		{
			if(high <= x)
			{
				high = x;
			}
		}
		return high;
	}
	public static double max(double[] array)
	{
		double high = 0;
		for(double x: array)
		{
			if(high <= x)
			{
				high = x;
			}
		}
		return high;
	}
	public static int min(int[] array)
	{
		int low = array[0];
		for(int x: array)
		{
			if(low >= x)
			{
				low = x;
			}
		}
		return low;
	}
	public static double min(double[] array)
	{
		double low = array[0];
		for(double x: array)
		{
			if(low >= x)
			{
				low = x;
			}
		}
		return low;
	}
	public static void print(int[] array)
	{
		for(int b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static void print(String[] array)
	{
		for(String b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static void print(double[] array)
	{
		for(double b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static void print(boolean[] array)
	{
		for(boolean b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static void print(char[] array)
	{
		for(char b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static void print(long[] array)
	{
		for(long b: array)
		{
			System.out.print(b+",");
		}
		System.out.println();
	}
	public static int indexOf(int[] array, int value)
	{
		int a = -1;
		for(int j = 0;j<array.length;j++)
		{
			if(array[j] == value)
			{
				a = j;
				break;
			}
			else
			{
				continue;
			}
		}
		return a;
	}
	public static int indexOf(double[] array, double value)
	{
		int a = -1;
		for(int j = 0;j<array.length;j++)
		{
			if(array[j] == value)
			{
				a = j;
				break;
			}
			else
			{
				continue;
			}
		}
		return a;
	}
	public static int[] randomIntArray(int size, int highest, int lowest)
	{
		int[] array = new int[size];
		for(int j = 0;j<size;j++)
		{
			array[j] = (int)(Math.random()*(highest-lowest)+1);
		}
		return array;
	}
	public static int[] copy(int[] array)
	{
		int[] copy = new int[array.length];
		int j=0;
		for(int b:array)
		{
			copy[j] = b;
			j++;
		}
		return copy;
	}
	public static char[] copy(char[] array)
	{
		char[] copy = new char[array.length];
		int j=0;
		for(char b:array)
		{
			copy[j] = b;
			j++;
		}
		return copy;
	}
	public static double[] copy(double[] array)
	{
		double[] copy = new double[array.length];
		int j=0;
		for(double b:array)
		{
			copy[j] = b;
			j++;
		}
		return copy;
	}
	public static String[] copy(String[] array)
	{
		String[] copy = new String[array.length];
		int j=0;
		for(String b:array)
		{
			copy[j] = b;
			j++;
		}
		return copy;
	}
	public static boolean[] copy(boolean[] array)
	{
		boolean[] copy = new boolean[array.length];
		int j=0;
		for(boolean b:array)
		{
			copy[j] = b;
			j++;
		}
		return copy;
	}
	public static void swap(int[] array, int index1, int index2)
	{
		if(index1>array.length||index2>array.length||index1<0||index2<0)
		{
			return;
		}
		else
		{
			int hold = array[index1];
			array[index1]=array[index2];
			array[index2]=hold;
		}
	}
	public static void shuffle(int[] array)
	{
		int s;
		for(int j = 0;j<array.length-1;j++)
		{
			s=(int)((Math.random()*array.length-1)+1);
			int hold = array[j];
			array[j]=array[s];
			array[s] = hold;
		}
	}
	public static void sort(int[] array)
	{
		boolean sorted = false;
		int temp;
		while(!sorted)
		{
			sorted=true;
			for(int i = 0; i < array.length-1;i++)
			{
				if(array[i]>array[i+1])
				{
					temp = array[i];
					array[i]= array[i+1];
					array[i+1] = temp;
					sorted = false;
				}
			}
		}
	}	
}

